const movieData = require('./movies');

module.exports = {
    movies: movieData
};
